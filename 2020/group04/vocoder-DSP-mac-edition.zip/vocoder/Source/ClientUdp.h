//
// Created by victor Letens on 28/11/20.
//

#ifndef CLIENTUDP_CLIENTUDP_H
#define CLIENTUDP_CLIENTUDP_H
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <cstdlib>
#include <string>
struct audioBlock{
    int channel;
    float value[512]={};
};

class ClientUdp {


public:
    ClientUdp(std::string ipAdressServer,int PORT_SERVER);
    bool send(audioBlock value);
private:
    int sock = 0, valread;
    struct sockaddr_in serv_addr;
};


#endif //CLIENTUDP_CLIENTUDP_H
