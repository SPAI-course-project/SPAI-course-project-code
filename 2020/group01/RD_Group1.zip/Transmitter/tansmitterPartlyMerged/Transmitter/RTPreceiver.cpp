#include "RTPreceiver.h"
#include "TransmitterFuncs.h"
using namespace jrtplib;
int nr_packet_received;
float defaults[1024] = {};
float* data = defaults;
std::shared_ptr<SMIPC::Server> server;

#ifdef RTP_SUPPORT_THREAD;



//
// This function checks if there was a RTP error. If so, it displays an error
// message and exists.
//

void RTPreceiver::checkerror(int rtperr)
{
	if (rtperr < 0)
	{
		std::cout << "ERROR: " << RTPGetErrorString(rtperr) << std::endl;
		exit(-1);
	}
}
float* RTPreceiver::getData()
{
	return data;
}

RTPreceiver::RTPreceiver()
{
}
class MyRTPSession : public RTPSession
{
protected:
	void OnPollThreadStep();
	void ProcessRTPPacket(const RTPSourceData& srcdat, const RTPPacket& rtppack);
	auto getData();
private:
};
MyRTPSession sess;
void MyRTPSession::OnPollThreadStep()
{
	BeginDataAccess();

	// check incoming packets
	if (GotoFirstSourceWithData())
	{
		do
		{
			RTPPacket* pack;
			RTPSourceData* srcdat;
			server=std::make_shared<SMIPC::Server>("Trans2DSP", 2, true);

			srcdat = GetCurrentSourceInfo();

			while ((pack = GetNextPacket()) != NULL)
			{
				ProcessRTPPacket(*srcdat, *pack);
				DeletePacket(pack);
			}
		} while (GotoNextSourceWithData());
	}

	EndDataAccess();
}

void MyRTPSession::ProcessRTPPacket(const RTPSourceData& srcdat, const RTPPacket& rtppack)
{
	// You can inspect the packet and the source's info here

	auto byteData = rtppack.GetPayloadData();
	float f1;
	float f2;
	float f3;
	memcpy(&f1, (BYTE*)byteData, sizeof(float));
	memcpy(&f2, (BYTE*)byteData + sizeof(float), sizeof(float));
	memcpy(&f3, (BYTE*)byteData + 2 * sizeof(float), sizeof(float));

	server->write((BYTE*)byteData);
	std::cout << "data_recv: " << f1 << "; " << f2 << "; " << f3 << std::endl;
}


//
// The main routine
// 
int RTPreceiver::receive(uint16_t portbaseIn, double waitTime)
{
#ifdef RTP_SOCKETTYPE_WINSOCK
	WSADATA dat;
	WSAStartup(MAKEWORD(2, 2), &dat);
#endif // RTP_SOCKETTYPE_WINSOCK

	portbase = portbaseIn;

	// Now, we'll create a RTP session, set the destination
	// and poll for incoming data.
	
	RTPUDPv4TransmissionParams transparams;
	RTPSessionParams sessparams;
	MyRTPSession sess;
	// IMPORTANT: The local timestamp unit MUST be set, otherwise
	//            RTCP Sender Report info will be calculated wrong
	// In this case, we'll be just use 8000 samples per second.
	sessparams.SetOwnTimestampUnit(1.0 / 8000.0);
	transparams.SetPortbase(portbase);
	status = sess.Create(sessparams, &transparams);
	checkerror(status);

	// Wait a number of seconds
	RTPTime::Wait(RTPTime(waitTime));

	sess.BYEDestroy(RTPTime(1, 0), 0, 0);

#ifdef RTP_SOCKETTYPE_WINSOCK
	WSACleanup();
#endif // RTP_SOCKETTYPE_WINSOCK
	return 0;
}





#else

int main(void)
{
	std::cerr << "Thread support is required for this example" << std::endl;
	return 0;
}

#endif // RTP_SUPPORT_THREAD


