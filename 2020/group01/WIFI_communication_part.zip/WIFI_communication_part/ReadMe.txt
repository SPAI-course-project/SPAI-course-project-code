This is the WIFI communication part of our project, which contains a RTP sender and a RTP receiver project configured in Visual Studio 2019, using jrtplib.
You can find the .exe file in ...\jrtplib_build\examples\Release, no building work is required. You can put the sender in one PC, and the receiver in another PC.   

It is suggested to launch RTP_receiver first, then RTP_sender. 
You can set the amount of packages sent by the sender, and how long the receiver should wait for the coming package. The sender should also specify the destination IP
of the receiver to connect it via WIFI.

The sender uses port 25000, receiver uses 25002 (You do not need to set this port yourself)

If you want to rebuild the project in Visual Studio, normally there will be no problems.
However, if you cannot rebuild directly, there may be several configurations needed to be done:
1. Right click the sender and receiver project, go to Properties

2. ->General -> Output Directories -> change the path according to you own.

3. -> C/C++ -> Additional Include Directories -> change the path according to you own.

4. -> C/C++ -> Preprocessor -> Preprocessor Definition, change to "WIN32;_WINDOWS;NDEBUG;CMAKE_INTDIR="Release";%(PreprocessorDefinitions)"

5. -> Linker -> All Options -> Change all the fields requiring path specification to your own. You should find three fields there. 

After the configuration above, it should be possible for you to rebuilt the project.   

The expected output is shown in the snapshot. In the demo, the sender will keep sending packages of 65400 Bytes every 100ms. The package 
contains a large float array (Other type of data is also possible to be sent). 
To visualize the received float data, the receiver will output three float values in it.

By testing, the transmission speed could reach 500 KB/s, the package loss rate is below 0.5%, robustness is guaranteed.
   