#include "TimeAligner.h"
#include <cmath>
#include <algorithm>

TimeAligner::TimeAligner(int bufferSize)
{
//  int order = 10;
//	this->oneFrameLength = pow(2, order);
    int order = int(log2(bufferSize));
    this->oneFrameLength = bufferSize;
	this->numOfFrames = storeSize/oneFrameLength;
	this->workingState = FillingBuffer;
	int FFTorder = log2(storeSize); // half of the store size plus zero padding
	this->oneBlockFFT = new dsp::FFT(order + 1); // frames + zeropadding: double the length
	this->bigFrameFFT = new dsp::FFT(FFTorder); // 8192=> 4096*2
	this->oneBlockWin = new dsp::WindowingFunction<float>(oneFrameLength + 1, dsp::WindowingFunction<float>::hann, false, 0.0f);  //one frame
	this->bigFrameWin = new dsp::WindowingFunction<float>(storeSize/2 +1, dsp::WindowingFunction<float>::hann, false, 0.0f);  //four frames
    this->outputM = new vector<float>(oneFrameLength, 0);
//  this->outputS = new vector<float>(oneFrameLength, 0);
    int outputChannel = 0; // 2 => output = second; 1 => output = ref.
}

TimeAligner::~TimeAligner()
{}

vector<float> TimeAligner::scaling(float* input, float scaler) {
    vector<float> outputS(input, input + oneFrameLength);
    //multiply each signal by desired scaler
    for (int m = 0;  < oneFrameLength; m++)
    {
        outputS[m] = scaler * output[m];
    }
    return *outputS;
}

vector<float> TimeAligner::mix(float* reference, float* secondChannel){
    vector<float> referenceInput(reference, reference + oneFrameLength);
    vector<float> secondInput(secondChannel, secondChannel + oneFrameLength);
    std::transform(referenceInput.begin(), referenceInput.end(), secondInput.begin(),
        (*outputM).begin(), std::plus<float>());
    return *outputM;
}

vector<float> TimeAligner::alignWithReference(float* reference, float* secondChannel) {
	//step 1: fill in the buffer
	vector<float> referenceInput(reference, reference + oneFrameLength);
	vector<float> secondInput(secondChannel, secondChannel + oneFrameLength);

	switch (workingState)
	{
	case FillingBuffer:
	{
		/*step 1: fill in the buffer*/
		referenceBuffer.push_back(referenceInput);
		secondChannelBuffer.push_back(secondInput);

		/*check if the buffer is full*/
		if (referenceBuffer.size() == numOfFrames)
		{
			workingState = Working;
		}
		break;
	}
	case Working:
	{
		//do time alignment first
		//step 1: loop each frame and calculate gccphat, save the maxNum, maxIndex, maxLag
		vector<float> bigRef = referenceBuffer[0];
		vector<float> bigSec = secondChannelBuffer[0];
		vector<float> calculateRef = referenceBuffer[0];

		int tempLag;
		float tempMaxC;
		for (int i = 0; i < numOfFrames; i++)
		{
			// append vectors
			if (i > 0)
			{
				bigRef.insert(bigRef.end(), referenceBuffer[i].begin(), referenceBuffer[i].end());
				bigSec.insert(bigSec.end(), secondChannelBuffer[i].begin(), secondChannelBuffer[i].end());
			}
			
			vector<float> calculateSec = secondChannelBuffer[i];
			//step 1: GCC-PHAT
			tempLag = gccPHAT(calculateRef, calculateSec, &tempMaxC);
			if (tempMaxC > maxCorre)
			{
				maxFrameIndex = i;
				maxLag = tempLag;
				maxCorre = tempMaxC;
			}
		}

		
		//step 4: mix
		if (maxLag > 0) //reference lead => start from the first frame of the reference => mostly the case => send aligned second signal to the output
		{
			//reference: 23456789
			//second:    12345678 => 2345678
            outputChannel = 2;
			int lag = maxFrameIndex * oneFrameLength + maxLag;
			if (lag + oneFrameLength < bigSec.size())
			{
				vector<float> second = vector<float>(bigSec.begin() + lag, bigSec.begin() + lag + oneFrameLength);
				// (done in mix function separately) mix them together
//				std::transform(referenceBuffer[0].begin(), referenceBuffer[0].end(), second.begin(), (*output).begin(), std::plus<float>());

			}
			else
			{
				vector<float> second = secondChannelBuffer[numOfFrames - 1];
				// (done in mix function separately) mix them together
//				std::transform(referenceBuffer[0].begin(), referenceBuffer[0].end(), second.begin(), (*output).begin(), std::plus<float>());

			}
            return *second;
		}
        
        
		else if (maxLag < 0)//reference lag => start from the first frame of the second channel => send aligned reference signal to the output
		{
			// reference: 000123456789 => 123456789
			// second:    123456789
            outputChannel = 1;
            int lag = maxFrameIndex * oneFrameLength + (-maxLag);
			if (lag + oneFrameLength < bigRef.size())
			{
				vector<float> refe = vector<float>(bigRef.begin() + lag, bigRef.begin() + lag + oneFrameLength);
				// (done in mix function separately) mix them together
//				std::transform(secondChannelBuffer[0].begin(), secondChannelBuffer[0].end(), refe.begin(), (*output).begin(), std::plus<float>());

			}
			else
			{
				vector<float> refe = referenceBuffer[numOfFrames - 1];
				// (done in mix function separately) mix them together
//				std::transform(secondChannelBuffer[0].begin(), secondChannelBuffer[0].end(), refe.begin(), (*output).begin(), std::plus<float>());

			}
            return *refe;
		}
        
        
		else// no alignment needed => no lag between the two signals => send ref to output
		{
            outputChannel = 1;
			// (done in mix function separately) mix them together
//			std::transform(secondChannelBuffer[0].begin(), secondChannelBuffer[0].end(), referenceBuffer[0].begin(), (*output).begin(), std::plus<float>());
            return *reference;
		}

		// step 5: delete the oldest data and insert new data
		referenceBuffer.erase(referenceBuffer.begin());
		referenceBuffer.push_back(referenceInput);

		secondChannelBuffer.erase(secondChannelBuffer.begin());
		secondChannelBuffer.push_back(secondInput);

		break;
	}
	
	}
	
}


int TimeAligner::gccPHAT(vector<float> ref, vector<float> sec, float* maxC)
{
	float* reference = ref.data();
	float* secondChannel = sec.data();

	int calculateLength = oneFrameLength;

	int newlength = 2 * calculateLength - 1;

	oneBlockWin->multiplyWithWindowingTable(reference, calculateLength);
	oneBlockWin->multiplyWithWindowingTable(secondChannel, calculateLength);

	vector<complex<float>> vReference(reference, reference + calculateLength);
	vector<complex<float>> vSecond(secondChannel, secondChannel + calculateLength);

	vector<complex<float>> zeros(calculateLength, 0);
	vector<complex<float>> XResult(calculateLength * 2, 0);
	vector<complex<float>> tresult(calculateLength * 2, 0);
	vector<complex<float>> XReference(calculateLength * 2, 0);
	vector<complex<float>> XSecond(calculateLength * 2, 0);

	/*step 1: zero padding*/
	vReference.insert(vReference.end(), zeros.begin(), zeros.end());
	vSecond.insert(vSecond.end(), zeros.begin(), zeros.end());
	
	/*step 2: fft*/
	oneBlockFFT->perform(vReference.data(), XReference.data(), false);
	oneBlockFFT->perform(vSecond.data(), XSecond.data(), false);
    
	/*step 3: vSecond time complex conjugate of vReference*/
	for (int i = 0; i <= newlength; i++)
	{
		complex<float> temp = XSecond[i] * std::conj(XReference[i]);
		float normalize = abs(temp);

		if (normalize == 0)
		{
			XResult[i] = 0;
		}
		else
		{
			XResult[i] = temp / normalize;
		}
	}

	/*step 4: ifft to get cross correlation*/
	oneBlockFFT->perform(XResult.data(), tresult.data(), true);
	/*step 5: reconstruct the vector*/
	vector<complex<float>> first(tresult.begin() + calculateLength + 1, tresult.end());
	vector<complex<float>> second(tresult.begin(), tresult.begin() + calculateLength);
	first.insert(first.end(), second.begin(), second.end());
	/*step 6: find the max crox*/
	float max = 0;
	int lag = 0;
	int index = 0;
	for (auto value : first) {
		if (value.real() > max)
		{
			max = value.real();
			lag = index;
		}
		index++;
	}
	*maxC = max;
	lag = lag - calculateLength + 1;
	return lag;
}
