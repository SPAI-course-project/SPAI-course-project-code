#pragma once
#include "MyRTPSession.h"
#include "rtpsession.h"
#include "rtppacket.h"
#include "rtpudpv4transmitter.h"
#include "rtpipv4address.h"
#include "rtpsessionparams.h"
#include "rtperrors.h"
#include "rtpsourcedata.h"

#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>

class RTPreceiver
{
public:
	RTPreceiver();
	~RTPreceiver();
	int receive(uint16_t portbaseIn, double waitTime);
	void checkerror(int rtperr);
	float* getData();

private:
	uint16_t portbase;
	int status;
	double waitTime;
};



