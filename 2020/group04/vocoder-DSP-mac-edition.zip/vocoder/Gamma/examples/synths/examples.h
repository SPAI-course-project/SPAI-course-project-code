/*	Gamma - Generic processing library
	See COPYRIGHT file for authors and license information
	
	Description:	Include files for Gamma examples	
*/

#include <stdio.h>				// for printing to stdout
#define GAMMA_H_INC_ALL			// define this to include all header files
#include "Gamma/Gamma.h"
using namespace gam;
