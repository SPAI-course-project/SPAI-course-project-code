/*
  ==============================================================================

    Dsp.cpp
    Created: 21 Nov 2020 1:36:42pm
    Author:  victor Letens

  ==============================================================================
*/
#include "Dsp.h"

DSP::DSP(unsigned WindowSize,unsigned HopSize,unsigned padSize,WindowType windowType, unsigned sampleRate):stft(WindowSize,HopSize,padSize,HAMMING,MAG_FREQ,3){
    STFT newStft(stft.numBins(),stft.numBins()/4,0,HANN,MAG_FREQ);
}

/*
DSP::DSP(unsigned WindowSize,unsigned HopSize,unsigned padSize,WindowType windowType,unsigned inputChannels,unsigned outputchannels, unsigned sampleRate):stft(WindowSize,HopSize,padSize,windowType,MAG_FREQ,3){
    activeInputChannels=inputChannels;
    activeOutputChannels=outputchannels;
    currentSampleRate=sampleRate;
}
*/
void DSP::process(ProcessActivity processActivity,const float* inputArrayPointer,float* outputArrayPointer, const unsigned numberOfSamples, unsigned sampleRate,float pshift,std::vector<float> notes,float tresholdFrequency, float compressionFactor){
    setcurrentSampleRate(sampleRate);
    float flux = 0;
    for (auto sample = 0; sample < numberOfSamples; ++sample){
        float s=inputArrayPointer[sample];
        if(stft(s)){
            flux = 0;
            
            for(unsigned k=0; k<stft.numBins(); ++k){
                float mcurr = stft.bin(k)[0];
//                if(mcurr < 0.0004) stft.bin(k)[0] = 0;

                float mprev = stft.aux(PREV_MAG)[k];
                    if(mcurr > mprev){
                        flux += mcurr - mprev;
                    }
            }
            stft.copyBinsToAux(0, PREV_MAG);
            for(unsigned k=0; k<stft.numBins(); ++k){
                stft.aux(TEMP_MAG)[k] = 0.;
                stft.aux(TEMP_FRQ)[k] = k*stft.binFreq();
            }
            if(flux > 0.2){
                stft.resetPhases();
            }
            switch (processActivity) {
                case PITCH_SHIFT:
                    pitchShift(pshift);
                    break;
                case AUTO_TUNE:
                    autoTune(notes);
                    break;
                case VOICE_COMPRESSION:
                    voiceCompression(tresholdFrequency, compressionFactor);
                case VOICE_COMPRESSION_AND_PITCH_SHIFT:
                    voiceCompression(tresholdFrequency, compressionFactor);
                    pitchShift(pshift);
                    break;
                default:
                    break;
            }
            stft.copyAuxToBins(TEMP_MAG, 0);
            stft.copyAuxToBins(TEMP_FRQ, 1);
        }
        s=stft();
        outputArrayPointer[sample]=s;
        
    }
}

void DSP::pitchShift(float pshift){
    
    unsigned kmax = stft.numBins()/pshift;
    if(kmax >= stft.numBins()) kmax = stft.numBins()-1;
    for(unsigned k=1; k<kmax; ++k){
        unsigned j = k*abs(pshift);
        stft.aux(TEMP_MAG)[j] += stft.bin(k)[0];
        stft.aux(TEMP_FRQ)[j] = stft.bin(k)[1]*pshift;
    }
}




void DSP::autoTune(std::vector<float> notes){
    float * cepstrum;
    for(int i=0;i<stft.numBins();i++){
        stft.bin(i)[TEMP_MAG]=std::log(stft.bin(i)[TEMP_MAG]);
    }
    stft.resetPhases();
    cepstrum=stft.bufferInverse();
    stft.inverse();
    float maxMagFreqFreq=0;
    float freq=0;
    for(int i=0;i<stft.numBins();i++){
        if(cepstrum[i]>maxMagFreqFreq){
            cepstrum[i]=maxMagFreqFreq;
            freq=i;
        }
    }
    freq*=(stft.binFreq()*stft.freqRes());
    std::cout<<freq<<std::endl;
    float pshift=1;
    float offset=INFINITY;


    for(int i=1; i<stft.numBins()-1;i++){
        if(newStft.bin(i)[TEMP_MAG]>maxMagFreqFreq){
            maxMagFreqFreq=newStft.bin(i)[TEMP_MAG];
            freq=i;
        }
    }
    maxMagFreqFreq*=currentSampleRate;
    std::cout<<maxMagFreqFreq<<std::endl;
    for(int i=0;i<notes.size();++i){
        if(abs(maxMagFreqFreq-notes.at(i))<abs(offset)){
            offset=maxMagFreqFreq-notes.at(i);
        } else{
            break;
        }
    }
    pshift=(maxMagFreqFreq+offset)/(maxMagFreqFreq);
    
    
    /*
    unsigned kmax = stft.numBins()-1;
    float maxMag=stft.bin(1)[0];
    float maxFreq=stft.bin(1)[1];
    for(unsigned k=1; k<kmax; ++k){
        if(maxMag<stft.bin(k)[0]){
            maxMag=stft.bin(k)[0];
            maxFreq=stft.bin(k)[1];
            maxFreq*=currentSampleRate;
            for(int i=0;i<notes.size();++i){
                if(abs(maxFreq-notes.at(i))<abs(offset)){
                    offset=maxFreq-notes.at(i);
                } else{
                    break;
                }
            }
            pshift=(maxFreq+offset)/(maxFreq);
        }
    }
    */
    pitchShift(pshift);
    
    
}


void DSP::voiceCompression(float tresholdFrequency,float factor){
    
    unsigned kmax = stft.numBins()-1;
    for(unsigned k=1; k<kmax; ++k){
        if(stft.bin(k)[1]*getcurrentSampleRate()>=tresholdFrequency){
            stft.bin(k)[0]=stft.bin(k)[0]/factor;
        }
    }
}

void DSP::compression(const float * inputBuffer,float * outBuffer,int numberOfSamples,int samplingRate,int treshold,float makeUpGain,int kneeWidth,int compressionRatio,int attackTime,int releaseTime){

    float alphaAttack=std::exp(-1/(attackTime*samplingRate));
    float alphaRelease=std::exp(-1/(releaseTime*samplingRate));
    
    std::vector<float> sideChain;
    std::vector<float> gainInput;
    std::vector<float> gainOutput;
    std::vector<float> peakInput;
    std::vector<float> peakOutput;
    std::vector<float> sideChainLin;

    for(int i=0;i<numberOfSamples;i++){
        //calculate abs
        sideChain.push_back(std::abs(inputBuffer[i]));
        
        //convert to db
        float iSideChain=sideChain.at(i);
        gainInput.push_back(20*std::log10(iSideChain));
        
        // Gain computer
        float iGainInput=gainInput.at(i);
        if(iGainInput<-100){
            iGainInput=-100;
        } else if (iGainInput>100){
            iGainInput=100;
        }
        
        if ((2*(iGainInput-treshold))<(-kneeWidth)) {
            gainOutput.push_back(iGainInput);
        } else if ((2*std::abs(iGainInput-treshold))<=kneeWidth){
            gainOutput.push_back(iGainInput+(std::pow((1/compressionRatio -1)*iGainInput-treshold+kneeWidth/2,2)/(2*kneeWidth)));
        } else {
            gainOutput.push_back(treshold+(iGainInput-treshold)/compressionRatio);
        }

        // input-output gain computer
        peakInput.push_back(gainInput.at(i)-gainOutput.at(i));
        
        // level detector
        if(i==0){
            peakOutput.push_back((1-alphaAttack)*peakInput.at(i));
        }else{
            if(peakInput.at(i)>peakOutput.at(i-1)){
                peakOutput.push_back(alphaAttack*peakOutput.at(i-1)+(1-alphaAttack)*peakInput.at(i));
            } else{
                peakOutput.push_back(alphaRelease*peakOutput.at(i-1)+(1-alphaRelease)*peakInput.at(i));

            }
        }
        
        //substract from makeUpGain
        peakOutput.at(i)=makeUpGain-peakOutput.at(i);
        
        // back to linear
        sideChainLin.push_back(std::pow(10,peakOutput.at(i))/20);
        outBuffer[i]=sideChainLin.at(i)*inputBuffer[i];
    }
}


