#pragma once

#include <JuceHeader.h>
#include "AudioDevice.h"
using namespace juce;
//==============================================================================
/*
    This component lives inside our window, and this is where you should put all
    your controls and content.
*/
class MainComponent  :  public juce::AudioAppComponent,
                        public juce::ChangeListener,
                        public Slider::Listener

{
public:
    //==============================================================================
    MainComponent();
    ~MainComponent() override;

    //==============================================================================
    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    //==============================================================================
    void paint (juce::Graphics& g) override;
    void resized() override;
    void changeListenerCallback(ChangeBroadcaster* source) override;
    void sliderValueChanged(Slider* slider) override
    {
        if(slider==&inputSlider){
            ratio = inputSlider.getValue();
            //logMessage("slider value has been changed to " + std::to_string(ratio));
        }
        
    };
private:
    //==============================================================================
    // Your private member variables go here...
    
    void infoButtonClicked();
    void logMessage(const juce::String& m)
    {
        diagnosticsBox.moveCaretToEnd();
        diagnosticsBox.insertTextAtCaret(m + juce::newLine);
        diagnosticsBox.insertTextAtCaret(juce::newLine);
    }
    Label bufferlabel;
    AudioDeviceManager otherDeviceManager;
    std::unique_ptr <AudioDeviceSelectorComponent> audioSettings;     

    AudioDevice subAudioDevice;

    juce::TextEditor diagnosticsBox;
    int position = 0;
    WaveScrollBar w;
    WaveScrollBar w2;

    WaveScrollBar w3;

    Slider inputSlider;

    TextButton infoButton;
    float ratio = 0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
