#pragma once
#include "../JuceLibraryCode/JuceHeader.h"
#include <vector>
#include <memory>
using namespace std;
enum State : int16_t { FillingBuffer, Working };

class TimeAligner
{
	
public:
	TimeAligner(int bufferSize);//2^order = bufferSize
	~TimeAligner();
	// alignWithReference will return a religned version of the lagging channel

	int gccPHAT(vector<float> ref, vector<float> sec, float* maxC);
    vector<float> scaling(float* input, float scaler)
    vector<float> mix(float* reference, float* secondChannel)
	vector<float> alignWithReference(float* reference, float* secondChannel);

private:
    int order;
	int oneFrameLength;
	int numOfFrames;
	const int storeSize = 4096;
    int FFTorder;
    int outputChannel;

	float maxCorre = 0;
	int maxFrameIndex = 0;
	int maxLag = 0;

	State workingState;
	vector<vector<float>> referenceBuffer; // This buffer acts as a circular buffer that stores previous input signals
	vector<vector<float>> secondChannelBuffer;

//	vector<float>* outputS;
    vector<float>* outputM;
	

	dsp::FFT* oneBlockFFT;
	dsp::FFT* bigFrameFFT;
	dsp::WindowingFunction<float>* oneBlockWin;
	dsp::WindowingFunction<float>* bigFrameWin;
};


