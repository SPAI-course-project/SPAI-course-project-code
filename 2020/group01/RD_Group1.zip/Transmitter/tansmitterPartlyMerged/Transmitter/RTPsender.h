#pragma once

#include "rtpsession.h"
#include "rtpudpv4transmitter.h"
#include "rtpipv4address.h"
#include "rtpsessionparams.h"
#include "rtperrors.h"
#include "rtplibraryversion.h"
#include <string>
#include <vector>
#include<chrono>
#include <stdlib.h>
#include <stdlib.h>
#include <iostream>

class RTPsender
{
public:
	RTPsender();
	~RTPsender();
	int send(void* data, uint16_t portbaseIn, std::string ipstrIn, uint16_t destportIn);
	void checkerror(int rtperr);
private:
	
	uint16_t portbase;
	uint16_t destport;
	uint32_t destip;
	std::string ipstr;
	int status, i, num;
};
