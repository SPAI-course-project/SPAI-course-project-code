
%% apply only BT signal
clear all; clc; close all;
[d, fs] = audioread('recording1.wav');
BT=d(:,2)';
delay=0.02;
period=0.1;
disp("set delay to "+delay+"s");
disp("set signal peropd to "+period+"s");
load=4;  
t=(0:fs*period);
 m=length(t);
 load=load*fs;
BT=BT(load:load+m-1);

N=50;
J=floor(delay*fs);
if J<0
    x1=[zeros(1,-J) BT]; 
    x2=[BT zeros(1,-J)];
else
    x1=[zeros(1,J) BT];
    x2=[BT zeros(1,J)];
end
M=length(x2); 
t=(0:M-1)/fs;
%% add noise
x1=x1+0.01*rand(size(x1));
%%  apply PC and BT signal
clear all; clc; close all;
[d, fs] = audioread('recording1.wav');
BT=d(:,2)';
PC=d(:,1)';
period=1;
load=4;
t=(0:fs*period);
 m=length(t);
 load=load*fs;
x2=BT(load:load+m-1);
x1=PC(load:load+m-1);


% %% plot original signal
% subplot(211);
% plot(t,x1,'r');
% hold on;
% plot(t,x2,'g');
% legend('x1', 'x2');
% xlabel('time/s');ylabel('x1(t) x2(t)');
% title('original signal');grid on;
% hold off
% %% cross correlation function 
% X1=fft(x1,2*m-1);
% X2=fft(x2,2*m-1);
% Sxy=X1.*conj(X2);
% Cxy=fftshift(ifft(Sxy));
% %Cxy=fftshift(real(ifft(Sxy)));
% subplot(212);
% t1=(0:2*m-2)/fs;                        
% plot(t1,Cxy,'b');
% title('cross correlation function');xlabel('time/s');ylabel('Rx1x2(t)');grid on
% clear location max;
% [max,location]=max(Cxy);%get max,and location;
% %d=location-N/2-1       
% d=location-m;
% Delay=d/fs;
% disp("Delay is "+ Delay);


%%
d=CCDE(x1,x2,1);
Delay=d/fs;
disp("Delay is "+ Delay);
%% test
PC_modify=PC;
PC_modify(1:d)=[];
PC_modify=[PC_modify,zeros(1,d)];

%%
sound([BT;PC],fs);
%%
sound([BT;PC_modify],fs);
%%
x1=PC_modify(load:load+m-1);
x2=BT(load:load+m-1);
Delay=CCDE(x1,x2,1)/fs;
disp("Delay is "+ Delay);
% subplot(211);
% plot(t,x1,'r');
% hold on;
% plot(t,x2,'g');
% legend('x1', 'x2');
% xlabel('time/s');ylabel('x1(t) x2(t)');
% title('original signal');grid on;
% hold off
% X1=fft(x1,2*m-1);
% X2=fft(x2,2*m-1);
% Sxy=X1.*conj(X2);
% Cxy=fftshift(ifft(Sxy));
% %Cxy=fftshift(real(ifft(Sxy)));
% subplot(212);
% t1=(0:2*m-2)/fs;                        
% plot(t1,Cxy,'b');
% title('cross correlation function');xlabel('time/s');ylabel('Rx1x2(t)');grid on
% clear location max;
% [max,location]=max(Cxy);%get max,and location;
% d=location-m-1  ;     
% Delay=d/fs;
% disp("Delay is "+ Delay);
%%
mu =  0.05;
lamda = 0.99;
M = 40;
[e1, y1, w1] = myLMS(BT, PC_modify, mu, M);
figure()
subplot(2,2,1)
plot([1:length(PC_modify)]/fs,PC_modify);
xlabel('time');
title('PC(n)');
subplot(2,2,2)
plot([1:length(BT)]/fs,BT);
xlabel('time');
title('BT(n)');
subplot(2,2,3)
plot([1:length(y1)]/fs,y1);
xlabel('time');
title('LMS y(n)');
subplot(2,2,4)
plot([1:length(e1)]/fs,e1);
xlabel('time');
title('LMS e(n)');
%%
sound(y1,fs)
%%
sound([BT;y1'],fs);