

#include "rtpsession.h"
#include "rtppacket.h"
#include "rtpudpv4transmitter.h"
#include "rtpipv4address.h"
#include "rtpsessionparams.h"
#include "rtperrors.h"
#include "rtpsourcedata.h"
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <string>
#include <fstream>
#include <chrono>

using namespace jrtplib;
int nr_packet_received; 
std::chrono::steady_clock::time_point begin;
#ifdef RTP_SUPPORT_THREAD

//
// This function checks if there was a RTP error. If so, it displays an error
// message and exists.
//

void checkerror(int rtperr)
{
	if (rtperr < 0)
	{
		std::cout << "ERROR: " << RTPGetErrorString(rtperr) << std::endl;
		exit(-1);
	}
}

//
// The new class routine
//

class MyRTPSession : public RTPSession
{
protected:
	void OnPollThreadStep();
	void ProcessRTPPacket(const RTPSourceData& srcdat, const RTPPacket& rtppack);
};

void MyRTPSession::OnPollThreadStep()
{
	BeginDataAccess();

	// check incoming packets
	if (GotoFirstSourceWithData())
	{
		do
		{
			RTPPacket* pack;
			RTPSourceData* srcdat;

			srcdat = GetCurrentSourceInfo();

			while ((pack = GetNextPacket()) != NULL)
			{
				ProcessRTPPacket(*srcdat, *pack);
				DeletePacket(pack);
			}
		} while (GotoNextSourceWithData());
	}

	EndDataAccess();
}

void MyRTPSession::ProcessRTPPacket(const RTPSourceData& srcdat, const RTPPacket& rtppack)
{
	// You can inspect the packet and the source's info here

	auto data_recv = rtppack.GetPayloadData();
	float f1;
	float f2;
	float f3;
	memcpy(&f1, (BYTE*)data_recv, sizeof(float));
	memcpy(&f2, (BYTE*)data_recv + 8000 * sizeof(float), sizeof(float));  //to show the received data at this index
	memcpy(&f3, (BYTE*)data_recv + 16000 * sizeof(float), sizeof(float));

	nr_packet_received++;
	std::cout << "data_recv: " << f1 << "; " << f2 << "; " <<f3 <<", Packet No. "<<nr_packet_received<<" packet length: " << rtppack.GetPayloadLength() <<std::endl;
	std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
	int count = std::chrono::duration_cast<std::chrono::microseconds>(end - begin).count();
	std::cout << "Time elapsed = "<< count/1000 << "[ms]" << ", Speed = " << nr_packet_received * 65400/ 1024 /(count/1000000) << " KB/s" << std::endl;
	std::chrono::time_point<std::chrono::system_clock> now;
}

//
// The main routine
// 

int main(void)
{
#ifdef RTP_SOCKETTYPE_WINSOCK
	WSADATA dat;
	WSAStartup(MAKEWORD(2, 2), &dat);
#endif // RTP_SOCKETTYPE_WINSOCK

	MyRTPSession sess;
	uint16_t portbase;
	std::string ipstr;
	int status, num;
	int nr_packet_received = 0;
	// First, we'll ask for the necessary information

	//std::cout << "Enter local portbase:" << std::endl;
	//std::cin >> portbase;
	//std::cout << std::endl;
	portbase = 25002;

	std::cout << std::endl;
	std::cout << "Number of seconds you wish to wait:" << std::endl;
	std::cin >> num;
	
	// Now, we'll create a RTP session, set the destination
	// and poll for incoming data.

	RTPUDPv4TransmissionParams transparams;
	RTPSessionParams sessparams;

	// IMPORTANT: The local timestamp unit MUST be set, otherwise
	//            RTCP Sender Report info will be calculated wrong
	// In this case, we'll be just use 8000 samples per second.
	sessparams.SetOwnTimestampUnit(1.0 / 8000.0);

	transparams.SetPortbase(portbase);
	begin = std::chrono::steady_clock::now();
	status = sess.Create(sessparams, &transparams);
	checkerror(status);

	// Wait a number of seconds
	RTPTime::Wait(RTPTime(num, 0));

	sess.BYEDestroy(RTPTime(10, 0), 0, 0);

#ifdef RTP_SOCKETTYPE_WINSOCK
	WSACleanup();
#endif // RTP_SOCKETTYPE_WINSOCK
	return 0;
}

#else

int main(void)
{
	std::cerr << "Thread support is required for this example" << std::endl;
	return 0;
}

#endif // RTP_SUPPORT_THREAD

