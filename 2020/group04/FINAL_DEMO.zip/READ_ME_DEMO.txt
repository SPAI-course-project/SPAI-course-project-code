Since many GUI components were broken during our demo, we felt we could not demonstrate some functionalities that were actually working.
In this demo, I did not touch any of the functional blocks that were used.
I only changed the link between GUI components and our function blocks.

I hope you can appreciate our efforts.
The sound recorded, is the sound that comes in and out of the primary device.