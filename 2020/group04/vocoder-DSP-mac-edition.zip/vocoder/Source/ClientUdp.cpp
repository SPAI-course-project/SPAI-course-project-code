//
// Created by victor Letens on 28/11/20.
//

#include "ClientUdp.h"
ClientUdp::ClientUdp(std::string ipAdress,int PORT) {
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("\n Socket creation error \n");
    }

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    // Convert IPv4 and IPv6 addresses from text to binary form
    if (inet_pton(AF_INET, ipAdress.c_str(), &serv_addr.sin_addr) <= 0) {
        printf("\nInvalid address/ Address not supported \n");
    }

    if (connect(sock, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
        printf("\nConnection Failed \n");
    }
}
bool ClientUdp::send(audioBlock value) {
    return(::send(sock, &value, sizeof(audioBlock), 0)!=-1);

}
