% ------------------------------------------------------------------------
%  Delay estimation using cross-correlation
%  Author:Song Gao
%  [Delay] = CCDE(x1,x2,PlotEnable)
%
% Inputs:
% x1,x2      - signals the delay need to be estimated
% PlotEnable - if 1, plot the original signal and cross-correlation
% 
% Outputs:
% Delay      - delay samples between x1 and x2, if > 0 x2 legging x1
%
% ------------------------------------------------------------------------

function [Delay] = CCDE(x1,x2,PlotEnable)

    % cross correlation function 
    m  = length(x1);
    if m ~= length(x2)
        print('error: mismatch between the length of x1 and x2��');
        return;
    end
    X1 = fft(x1,2*m-1);
    X2 = fft(x2,2*m-1);
    Sxy = X1.*conj(X2);
    Cxy = fftshift(ifft(Sxy));
    %Cxy=fftshift(real(ifft(Sxy)));
    [~,location] = max(Cxy);%get max,and location;
    %d=location-N/2-1       
    Delay = location-m;

    %disp("Delay is "+ Delay);

    % plot original signal
    
    if PlotEnable==1
        t=[1:m];
        subplot(211);
        plot(t,x1,'r');
        hold on;
        plot(t,x2,'g');
        legend('x1', 'x2');
        xlabel('sample');ylabel('x1(t) x2(t)');
        title('original signal');grid on;
        hold off
        subplot(212);
        t1=(0:2*m-2);                        
        plot(t1,Cxy,'b');
        title('cross correlation function');xlabel('samples');ylabel('Rx1x2(t)');grid on
    end

    end

