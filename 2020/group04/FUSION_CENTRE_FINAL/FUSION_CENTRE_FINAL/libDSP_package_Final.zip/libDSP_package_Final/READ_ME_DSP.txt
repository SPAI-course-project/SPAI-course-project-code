WAAR NIEUWE DIRECTORIES MAKEN?
JuceDirectory = map waarin .jucer project file staat

JuceDirectory\Builds\VisualStudio2019 => HIER libs folder maken.

WELKE FILES STAAN WAAR?
Alle files in source_directory (libdsp.h) bij JuceDirectory\Source
Alle files in lib_directory (alle andere .h files + .lib file) bij JuceDirectory\Builds\VisualStudio2019\libs
Alle files in runtime_directory (alle .dll files) bij JuceDirectory\Builds\VisualStudio2019\Win32\Debug\App

EXPORTERS - DEBUG
HEADER SEARCH PATHS
$(SolutionDir)libs\

EXTRA LIBRARY SEARCH PATHS
$(SolutionDir)libs\

ARCHITECTURE
Win32

IN VISUAL STUDIO
PROJECT PROPERTIES -> LINKER -> INPUT -> ADDITIONAL DEPENDENCIES:
dspDLL.lib