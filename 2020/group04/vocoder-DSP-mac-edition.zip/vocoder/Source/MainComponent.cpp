
 #include "MainComponent.h"
 using namespace juce;
 using namespace std::chrono;

     //==============================================================================
void showConnectionErrorMessage (const juce::String& messageText)
    {
        juce::AlertWindow::showMessageBoxAsync (juce::AlertWindow::WarningIcon,
                                                "Connection error",
                                                messageText,
                                                "OK");
    }
// 192.168.0.184
MainComponent::MainComponent():dsp(2048, 512, 0, HAMMING, 0)
//client("127.0.0.1", 100)

 {
     // Make sure you set the size of the component after
     // you add any child components.
     
     levelSlider.setRange (0.5, 2  );
     levelSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 100, 20);
     levelLabel.setText ("pitch shift", juce::dontSendNotification);
     delayLabel.setJustificationType (juce::Justification::centred);

     addAndMakeVisible (levelSlider);
     addAndMakeVisible (levelLabel);
     addAndMakeVisible (delayLabel);

     setSize (600, 100);

     // Some platforms require permissions to open input channels so request that here
     if (juce::RuntimePermissions::isRequired (juce::RuntimePermissions::recordAudio)
         && ! juce::RuntimePermissions::isGranted (juce::RuntimePermissions::recordAudio))
     {
         juce::RuntimePermissions::request (juce::RuntimePermissions::recordAudio,
                                            [&] (bool granted) { setAudioChannels (granted ? 2 : 0, 2); });
     }
     else
     {
         // Specify the number of input and output channels that we want to open
         setAudioChannels (2, 2);
     }


 }

 MainComponent::~MainComponent()
 {
     // This shuts down the audio device and clears the audio source.
     shutdownAudio();
 }

 //==============================================================================
 void MainComponent::prepareToPlay (int samplesPerBlockExpected, double sampleRate)
 {
     // This function will be called when the audio device is started, or when
     // its settings (i.e. sample rate, block size, etc) are changed.
     levelSlider.setValue(1);
     //ScopedPointer<AudioFormatReader> reader = afm.createReaderFor (new MemoryInputStream(BinaryData::myaudiofile_wav, BinaryData::myaudiofile_wavSize, false));
     // You can use this function to initialise any resources you might need,
     // but be careful - it will be called on the audio thread, not the GUI thread.

     // For more details, see the help for AudioProcessor::prepareToPlay()
}



 void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill)
 {
     float pshift=(float) levelSlider.getValue();
     
     auto* device = deviceManager.getCurrentAudioDevice();
     auto activeInputChannels  = device->getActiveInputChannels();
     auto activeOutputChannels = device->getActiveOutputChannels();
     auto maxInputChannels  = activeInputChannels .getHighestBit() + 1;
     auto maxOutputChannels = activeOutputChannels.getHighestBit() + 1;
     auto samplingRate=device->getCurrentSampleRate();
     float Amajor[7]={261.6,293.7,329.7,349.2,392,440,493};
     float notes[88]={27.5000000000000,29.1352350948806,30.8677063285078,32.7031956625748,34.6478288721090,36.7080959896759,38.8908729652601,41.2034446141087,43.6535289291255,46.2493028389543,48.9994294977187,51.9130871974931,55,58.2704701897612,61.7354126570155,65.4063913251497,69.2956577442180,73.4161919793519,77.7817459305202,82.4068892282175,87.3070578582510,92.4986056779086,97.9988589954373,103.826174394986,110,116.540940379522,123.470825314031,130.812782650299,138.591315488436,146.832383958704,155.563491861040,164.813778456435,174.614115716502,184.997211355817,195.997717990875,207.652348789973,220,233.081880759045,246.941650628062,261.625565300599,277.182630976872,293.664767917408,311.126983722081,329.627556912870,349.228231433004,369.994422711634,391.995435981749,415.304697579945,440,466.163761518090,493.883301256124,523.251130601197,554.365261953744,587.329535834815,622.253967444162,659.255113825740,698.456462866008,739.988845423269,783.990871963499,830.609395159890,880,932.327523036180,987.766602512248,1046.50226120239,1108.73052390749,1174.65907166963,1244.50793488832,1318.51022765148,1396.91292573202,1479.97769084654,1567.98174392700,1661.21879031978,1760,1864.65504607236,1975.53320502450,2093.00452240479,2217.46104781498,2349.31814333926,2489.01586977665,2637.02045530296,2793.82585146403,2959.95538169308,3135.96348785399,3322.43758063956,3520,3729.31009214472,3951.06641004899,4186.00904480958};
     std::vector<float>* testNotes=new std::vector<float>();
     for(int i=0; i<88;i+=4){
         testNotes->push_back(notes[i]);
     }

     auto start = high_resolution_clock::now();
     for (auto channel = 0; channel < maxOutputChannels; ++channel)
                  {
                      if ( (!activeOutputChannels[channel])||maxInputChannels == 0)
                      {
                          bufferToFill.buffer->clear (channel, bufferToFill.startSample, bufferToFill.numSamples);
                      }
                   
                      else
                      {
                          const auto* inputBuffer=bufferToFill.buffer->getReadPointer (channel, bufferToFill.startSample);
                          auto* outBuffer = bufferToFill.buffer->getWritePointer (channel, bufferToFill.startSample);
                          dsp.process(PITCH_SHIFT, inputBuffer, outBuffer, bufferToFill.numSamples,samplingRate, pshift, *testNotes,2000,5);

                          //parameters for compression
                          //int treshold=-10;
                          //float makeUpGain=2.1;
                          //int kneeWidth=10;
                          //int compressionRatio=20;
                          //int attackTime=2;
                          //int releaseTime=40;
                          //int SR=samplingRate;
                          //compression(inputBuffer,outBuffer,bufferToFill.numSamples,samplingRate,treshold,makeUpGain,kneeWidth,compressionRatio,attackTime,releaseTime);
                }
          }
        
          auto stop = high_resolution_clock::now();
          auto duration = duration_cast<microseconds>(stop - start);
          
//          printf ("time taken for function() %ld microseconds.\n", duration );
       //   maxOutputChannels = activeOutputChannels.getHighestBit()

 }

 void MainComponent::releaseResources()
 {
     // This will be called when the audio device stops, or when it is being
     // restarted due to a setting change.

     // For more details, see the help for AudioProcessor::releaseResources()
 }

 //==============================================================================
 void MainComponent::paint (juce::Graphics& g)
 {
     // (Our component is opaque, so we must completely fill the background with a solid colour)
     g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

     // You can add your drawing code here!
 }

 void MainComponent::resized()
 {
     levelLabel .setBounds (10, 10, 90, 20);
     levelSlider.setBounds (100, 10, getWidth() - 110, 20);
     delayLabel .setBounds (110, 110, 190, 120);
 }

    
